<footer class="bg-gray-900 text-white p-4">
    <div class="container mx-auto text-center">
        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>
    </div>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
