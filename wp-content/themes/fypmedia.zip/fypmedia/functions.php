function fypmedia_enqueue_styles() {
    wp_enqueue_style('tailwind-style', get_template_directory_uri() . '/assets/css/style.css', array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'fypmedia_enqueue_styles');


function fypmedia_custom_post_types() {
    register_post_type('team', array(
        'label' => 'Team',
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'has_archive' => true,
    ));
}
add_action('init', 'fypmedia_custom_post_types');
